class LoginPage {

  visit() {
    cy.visit('https://www.saucedemo.com/')
  }

  username() {
    return cy.get('#user-name')
  }

  password() {
    return cy.get('#password')
  }

  loginBtn() {
    return cy.get('#login-button')
  }

  errorMsg() {
    return cy.get('[data-test="error"]')
  }
}

export default LoginPage
