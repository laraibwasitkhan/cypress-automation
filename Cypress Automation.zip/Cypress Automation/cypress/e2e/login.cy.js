import LoginPage from '../../Pages/LoginPage'


describe('Login Tests', () => {

  const loginPage = new LoginPage()

  beforeEach(() => {
    loginPage.visit()
  })

  it('Login should fail with invalid credentials', () => {
    loginPage.username().type('wrong_user')
    loginPage.password().type('wrong_pass')
    loginPage.loginBtn().click()

    loginPage.errorMsg()
      .should('be.visible')
      .and('contain', 'Username and password do not match')
  })
})

  it('Login should succeed with valid credentials', () => {
    loginPage.username().type('standard_user')
    loginPage.password().type('secret_sauce')
    loginPage.loginBtn().click()

    cy.url().should('include', '/inventory.html')
    cy.get('.inventory_list').should('be.visible')
  })

    it('User should navigate to product details page', () => {
    loginPage.username().type('standard_user')
    loginPage.password().type('secret_sauce')
    loginPage.loginBtn().click()

    cy.get('.inventory_item').first().click()
    cy.get('.inventory_details_name').should('be.visible')
  })
